import sockfunctions
import threading
import time

host_ip = '10.167.89.232'
connected_ip = '10.167.89.232'

if __name__ == '__main__':
    server = threading.Thread(target=sockfunctions.start_server, args=(host_ip,))
    server.setDaemon(True)
    server.start()
    time.sleep(2)
    sockfunctions.start_client(connected_ip)
